import { getOrganisationsQuery } from "./getAllOrganisationsInEnterprise";
import { getRepositoriesQuery } from "./getAllRepositoriesInOrganisation";

export { getOrganisationsQuery, getRepositoriesQuery };
